let data = [
    {
      "id" : 0,
      "title" : "white and Black",
      "content" : "Born in France",
      "price" : 120000
    },
    {
      "id" : 1,
      "title" : "Red Knit",
      "content" : "Born in Seoul",
      "price" : 110000
    },
    {
      "id" : 2,
      "title" : "Grey Yordan",
      "content" : "Born in States",
      "price" : 110000
    }
  ];

export default data;  